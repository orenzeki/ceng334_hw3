from copy import deepcopy
from time import sleep
import subprocess
import os
imageContentsHandle = open("imageContents.txt", "r")
lines = imageContentsHandle.readlines()
imageContents = []

for line in lines:
	stripped = deepcopy(line)
	stripped = stripped.strip("\n")
	stripped = stripped.strip("]")
	stripped = stripped.strip("[")
	stripped = stripped.replace(" ", "")
	stripped = stripped.replace("'", "")
	splitted = stripped.split(",")
	imageContents.append(splitted)

getRunningFolder = subprocess.check_output("pwd", shell=True).split("\n")
currentFolder = getRunningFolder[0] + "/"

imageFolder = currentFolder + "originalImages/"
editedImagesFolder = currentFolder + "editedImages"
mountFolder = currentFolder + "mountFolder/"
tempFolder = currentFolder + "tempFolder/"
lostFound = mountFolder + "lost+found/"
randomFolder = currentFolder + "randomTextFiles/"

deleteTempCommand_safety = "rm -rf " + tempFolder
createTempCommand_safety = "mkdir " + tempFolder
unmountImageCommand_safety = "fusermount -u " + mountFolder

imagePaths = []
for rootName, dirNames, fileNames in sorted(os.walk(imageFolder)):
	for fileName in fileNames:
		imagePath = imageFolder + fileName
		imagePaths.append(imagePath)

getMD5SumOfRandoms = "md5sum " + randomFolder + "*"
md5RandomTexts = subprocess.check_output(getMD5SumOfRandoms, shell=True).split("\n")
originalMD5sums = {}
print("FILE MD5Sums:")
for line in md5RandomTexts:
	if line != '':
		# print line
		splitted = line.split("  ")
		# print splitted
		fileName = splitted[1].split("/")[-1]
		md5Local = splitted[0]
		print fileName, md5Local
		originalMD5sums[md5Local] = fileName
print("\n")

print("IMAGE Contents:")
print("! Note that these files are deleted,")
print("! will not be visible when you mount the image")
contentIndex = 0
for imageContent in imageContents:	
	print contentIndex, sorted(imageContent)
	contentIndex += 1
print("\n")

# for early terminated codes, these resolves conflicts
subprocess.check_output(deleteTempCommand_safety, shell=True)
subprocess.check_output(createTempCommand_safety, shell=True)

try:
	result = subprocess.check_output(unmountImageCommand_safety, shell=False)
except:
	pass

print "Preparing the environment\n"
sleep(2)

index = 0
totalImages = len(imagePaths)
success = 0
for imagePath in sorted(imagePaths):


	moveImageCommand = "cp " + imagePath + " " + currentFolder
	# print(moveImageCommand)
	os.system(moveImageCommand)
	
	imageName = imagePath.split("/")[-1]
	newImagePath = currentFolder + imageName
	print("./recover " + newImagePath)
	subprocess.check_output("./recover " + newImagePath, shell=True)
	
	mountImageCommand = "fuseext2 -o rw+ " + newImagePath + " " + mountFolder
	# print(mountImageCommand)
	subprocess.check_output(mountImageCommand, shell=True)

	moveRecoveredCommand = "cp " + lostFound + "* " + tempFolder
	# print(moveRecoveredCommand)
	subprocess.check_output(moveRecoveredCommand, shell=True)


	md5sumRecoveredCommand = "md5sum " + tempFolder + "*"
	recoveredMD5s = subprocess.check_output(md5sumRecoveredCommand, shell=True).split("\n")
	
	onlyMD5Sums = []
	for line in recoveredMD5s:
		if line != '':
			splitted = line.split("  ")
			fileName = splitted[1].split("/")[-1]
			md5Local = splitted[0]
			onlyMD5Sums.append(md5Local)

	
	
	validationSet = []
	for md5Text in onlyMD5Sums:
		if md5Text in originalMD5sums:
			fileName = originalMD5sums[md5Text]
			# print "	Rescued: " + fileName
			validationSet.append(fileName)
		else:
			pass
			# print "	Find a file in your image, but your file's content does not match with any"

	
	

	if sorted(validationSet) == sorted(imageContents[index]):
		print "Image #" + str(index), "PASS"
		# print "Original Image: ", imageContents[index]
		# print "Your Image     : ", validationSet
		success += 1
	else:
		print "Image #" + str(index), "FAIL"
		print "Original Image: ", imageContents[index]
		print "Your Image    : ", validationSet

	print("\n")

	unmountImageCommand = "fusermount -u " + mountFolder
	while True:
		try:
			subprocess.check_output(unmountImageCommand, shell=True)
			break
		except:
			sleep(1)
			continue

	deleteRecoveredCommand = "rm -f " + tempFolder + "*"
	os.system(deleteRecoveredCommand)

	moveEditedImageCommand = "mv " + newImagePath + " " + editedImagesFolder
	os.system(moveEditedImageCommand)

	index+=1

print str(success) + "/" + str(totalImages)

